'use strict';

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

const setup = require('./starter-kit/setup');
const fs = require('fs');
const unescape = require('lodash.unescape');
const otherListeners = require('./otherListeners.js');

exports.handler = (() => {
  var _ref = _asyncToGenerator(function* (event, context, callback) {
    // For keeping the browser launch
    context.callbackWaitsForEmptyEventLoop = false;

    const body = JSON.parse(event.body);

    if (body.event.type === 'member_left_channel' || body.event.type === 'team_join') {
      return otherListeners(body, callback);
    }

    const { WebClient } = require('@slack/client');
    const web = new WebClient(process.env.SLACK_TOKEN);

    console.log('********The initial information from slack: ', event.body, event, '********');
    const browser = yield setup.getBrowser();

    const channel = body.event.channel;

    let preTransformUrl = body.event.links[0].url;
    console.log('url pre transform ', preTransformUrl);
    let url = unescape(preTransformUrl);
    console.log('url post transform ', url);

    const ts = body.event.message_ts;

    const page = yield browser.newPage();

    yield page.goto(process.env.LOGIN_URL);

    console.log('********Redirected to login********');
    yield page.evaluate(function (username, password) {
      const inputs = document.querySelectorAll('input');
      inputs[0].value = username;
      inputs[1].value = password;
      document.querySelector('form').submit();
    }, process.env.USERNAME, process.env.PASSWORD);

    console.log('********Creds Inserted and Accepted********');

    const page2 = yield browser.newPage();

    yield page2.goto(url);

    yield page2.waitForNavigation({
      waitUntil: 'networkidle',
      networkIdleTimeout: 500
    });

    console.log('past the url');

    console.log('********Preparing to Take Screenshot********');

    yield page2.screenshot({
      path: '/tmp/temp.jpeg',
      type: 'jpeg',
      quality: 50
    });

    yield browser.close();

    console.log('********Preparing to Upload Screenshot********');

    web.files.upload('ss_bot.jpeg', {
      file: fs.createReadStream(`/tmp/temp.jpeg`),
      text: ' ',
      channels: ['C8K0U8ZUJ']
    }).then(function (res) {
      console.log('********Screenshot Uploaded********');
      return res;
    }).then(function (res) {
      console.log('response from upload', res);
      // res.url_private
      const unfurls = {
        [preTransformUrl]: {
          title: 'Marcel Please!',
          image_url: res.file.url_private,
          color: '#764FA5'
        }
      };
      return web.chat.unfurl(ts, channel, unfurls);
    }).then(function (res) {
      callback(null, { statusCode: 200, body: {}, data: {} });
    }).catch(function (err) {
      console.log(err);
    });
  });

  return function (_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
})();