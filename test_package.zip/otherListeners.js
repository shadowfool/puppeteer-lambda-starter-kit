'use strict';

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

module.exports = (() => {
    var _ref = _asyncToGenerator(function* (body, callback) {
        const { WebClient } = require('@slack/client');
        const web = new WebClient(process.env.SLACK_TOKEN);

        const channel = body.event.channel;

        if (body.event.type === 'member_left_channel') {
            yield web.chat.postMessage({
                channel,
                text: 'And now his watch is ended...'
            });
            callback(null, { statusCode: 200, body: {}, data: {} });
        } else if (body.event.type === 'team_join') {
            yield web.chat.postMessage({
                channel: 'C3U613NSV',
                text: 'A new foe has appeared!'
            });
            callback(null, { statusCode: 200, body: {}, data: {} });
        }
    });

    return function (_x, _x2) {
        return _ref.apply(this, arguments);
    };
})();